import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  return (
    <View style={styles.container}>
    <Image source={{ uri: "https://www.kaytee.com/-/media/Images/Kaytee-NA/US/learn-care/ask-the-pet-bird-experts/ways-to-show-parrot-love/PARROT%20png.png?h=304&la=en&w=499&hash=D9B5C2B1A3D578FB86E0237C99E4DB6E2BB9878C" }} style={styles.logo}/>
      <Text style={styles.paragraph}>
        Hello World from Group 4  group member Tomass Janis Rags!
      </Text>
      <Text style={styles.paragraph}>
      This is my Tomasa Jaņa Raga first React Native application!
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#111',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color : 'violet'
  },
  logo:{
    width :150,
    height:140,
  },
});
